﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMS
{
    public partial class UpdateTC : MetroFramework.Forms.MetroForm
    {
        public UpdateTC()
        {
            InitializeComponent();
        }
        public SqlDataAdapter da;
        public SqlDataReader dr;

        Connect dbconn = new Connect();
        DataTable dt = new DataTable();
        public static string customer = null, number = null, age = null, address = null, card = null;

        private void metroTile2_Click(object sender, EventArgs e)
        {
            customer = metroTextBox4.Text;
            number = metroTextBox1.Text;
            age = metroTextBox5.Text;
            address = metroTextBox7.Text;
            card = metroTextBox3.Text;
            TMSQuerry qp = new TMSQuerry();
            qp.UpdateTransportCard(customer, number, age, address, card);
            DisplayData();
            ClearData();

        }

        private void ClearData()
        {
            metroTextBox4.Clear();
            metroTextBox1.Clear();
            metroTextBox5.Clear();
            metroTextBox7.Clear();
            metroTextBox3.Clear();
            
        }

        private void metroGrid1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            metroTextBox4.Text = metroGrid1.Rows[e.RowIndex].Cells[0].Value.ToString();
            metroTextBox1.Text = metroGrid1.Rows[e.RowIndex].Cells[1].Value.ToString();
            metroTextBox5.Text = metroGrid1.Rows[e.RowIndex].Cells[2].Value.ToString();
            metroTextBox7.Text = metroGrid1.Rows[e.RowIndex].Cells[3].Value.ToString();
            metroTextBox3.Text = metroGrid1.Rows[e.RowIndex].Cells[4].Value.ToString();
            
        }

        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void metroTile5_Click(object sender, EventArgs e)
        {
            
            card = metroTextBox3.Text;
            TMSQuerry qp = new TMSQuerry();
            qp.DeleteTransportCard(card);
            DisplayData();
            ClearData();
        }
       
        //Display Data in DataGridView  
        private void DisplayData()
        {
            DataTable dt = new DataTable();
            string query = " select CustomerName, ContactNumber, Age, C_Address, TransportCardNo  from[C_Transport]";
            dt = dbconn.getData(query);

            metroGrid1.DataSource = dt;
        }
        private void UpdateTC_Load(object sender, EventArgs e)
        {

        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
        
            DisplayData();
        
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            TransportCardDetail form = new TransportCardDetail();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }
    }
}
