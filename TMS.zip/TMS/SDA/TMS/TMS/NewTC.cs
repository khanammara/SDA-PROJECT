﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMS
{

  
    public partial class NewTC : MetroFramework.Forms.MetroForm
    {
        public static string customer = null, number = null, age = null, address = null, card = null;

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            Transportation form = new Transportation();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }

        public NewTC()
        {
            InitializeComponent();
        }

        private void NewTC_Load(object sender, EventArgs e)
        {

        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
            customer = metroTextBox4.Text;
            number = metroTextBox1.Text;
            age = metroTextBox5.Text;
            address = metroTextBox7.Text;
            card = metroTextBox3.Text;
         

            TMSQuerry qp = new TMSQuerry();

            qp.AddTransportCard(customer, number, age, address, card);
            qp.UpdateTransportCard(customer, number, age, address, card);
            ClearData();

            //TransportCardDetail tcd = new TransportCardDetail();
           
        }

        private void ClearData()
        {
            metroTextBox4.Clear();
            metroTextBox1.Clear();
            metroTextBox5.Clear();
            metroTextBox7.Clear();
            metroTextBox3.Clear();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            TransportCardDetail form = new TransportCardDetail();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }
    }
}
