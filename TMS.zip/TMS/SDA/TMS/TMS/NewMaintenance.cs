﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMS
{
    public partial class NewMaintenance : MetroFramework.Forms.MetroForm
    {
        public static string m_id = null, manager = null, vehicle = null, type = null, 
            desc = null, date = null, cost = null, status = null;

        private void metroTile1_Click(object sender, EventArgs e)
        {
            Maintenance form = new Maintenance();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }

        public NewMaintenance()
        {
            InitializeComponent();
        }

        private void NewMaintenanace_Load(object sender, EventArgs e)
        {

        }
        private void metroTile2_Click(object sender, EventArgs e)
        {
            m_id = metroTextBox3.Text;
            manager = metroTextBox4.Text;
            vehicle = metroTextBox1.Text;
            type = metroComboBox1.Text;
            desc = metroTextBox5.Text;
            cost = metroTextBox2.Text;
            status = metroComboBox2.Text;

            TMSQuerry qp = new TMSQuerry();

            qp.AddMaintenance(m_id, manager, vehicle, type, desc, cost, status);
            metroTextBox3.Text = "";
            metroTextBox4.Text = "";
            metroTextBox1.Text = "";
            metroComboBox1.Text = "";
            metroTextBox5.Text = "";
            metroTextBox2.Text = "";
            metroComboBox1.Text = "";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Maintenance form = new Maintenance();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }
    }
}
