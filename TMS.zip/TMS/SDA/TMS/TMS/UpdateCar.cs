﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMS
{
    public partial class UpdateCar : MetroFramework.Forms.MetroForm
    {
        public UpdateCar()
        {
            InitializeComponent();
        }


        public SqlDataAdapter da;
        public SqlDataReader dr;
        SqlConnection conn;
        public string constring = "Data Source=DESKTOP-3PLMV60;Initial Catalog=TMS;Integrated Security=True";
        public static string carid = null, rate = null;

        private void DisplayData()
        {
            conn = new SqlConnection(constring);
            conn.Open();
            DataTable dt = new DataTable();
            da = new SqlDataAdapter("select  *  from [CarType]", conn);
            da.Fill(dt);
            metroGrid1.DataSource = dt;
            conn.Close();
        }
        private void UpdateCar_Load(object sender, EventArgs e)
        {

        }

        private void metroTile5_Click(object sender, EventArgs e)
        {
            carid = metroTextBox3.Text;

            TMSQuerry qp = new TMSQuerry();
            qp.DeleteCarRecord(carid);
            DisplayData();
            ClearData();
        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
          
            DisplayData();
        
        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
            carid = metroTextBox7.Text;
            rate = metroTextBox3.Text;

            TMSQuerry qp = new TMSQuerry();

            qp.UpdateCarRecord(carid, rate);
            DisplayData();
            ClearData();
        }

        private void metroGrid1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
           
            metroTextBox7.Text = metroGrid1.Rows[e.RowIndex].Cells[2].Value.ToString();
            metroTextBox3.Text = metroGrid1.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void metroTextBox3_Click(object sender, EventArgs e)
        {

        }

        private void metroTile3_Click(object sender, EventArgs e)
        {
            CarRecord form = new CarRecord();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }

        private void ClearData()
        {
         
          
            metroTextBox7.Clear();
            metroTextBox3.Clear();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            CarRecord form = new CarRecord();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }

    }
}
