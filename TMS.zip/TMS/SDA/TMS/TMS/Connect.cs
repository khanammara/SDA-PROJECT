﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMS
{
    class Connect
    {
        SqlConnection conn;
        SqlCommand cmd;

        public Connect()
        {

            conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C: \Users\AHSAN\Desktop\New folder\project\project\Fit(TMS)\DBMS\TMS(DB)\Sql File\TMSystem.mdf;Integrated Security=True;Connect Timeout=30");


        }

        public DataTable getData(string sqlQuery)
        {
            DataTable dt = new DataTable();

            conn.Open();
            cmd = new SqlCommand(sqlQuery, conn);
            dt.Load(cmd.ExecuteReader());
            conn.Close();

            return dt;
        }

        public bool iud(string sqlQuery)
        {
            bool b = false;
            conn.Open();
            cmd = new SqlCommand(sqlQuery, conn);
            int check = cmd.ExecuteNonQuery();
            conn.Close();
            if (check > 0)
            {
                b = true;
            }
            else
            {
                b = false;

            }
            return b;
        }
    }
}
