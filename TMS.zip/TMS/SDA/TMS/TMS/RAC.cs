﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMS
{
    public partial class RAC : MetroFramework.Forms.MetroForm
    {
        public RAC()
        {
            InitializeComponent();
        }
        public static string cname = null, contact = null, cartype = null, duration = null, date = null, rent = null;
        private void RAC_Load(object sender, EventArgs e)
        {

        }

        private void metroLabel3_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel4_Click(object sender, EventArgs e)
        {

        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            Reservation form = new Reservation();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
            cname = metroTextBox4.Text;
            contact = metroTextBox1.Text;
            cartype = metroComboBox2.Text;
            duration = metroTextBox3.Text;
            date = metroDateTime1.Text;
            rent = metroTextBox2.Text;
          

            TMSQuerry qp = new TMSQuerry();

            qp.AddRACReservation(cname, contact, cartype, duration, date, rent);

            ClearData();
        }

        private void ClearData()
        {

            metroTextBox4.Clear(); ;
            metroTextBox1.Clear(); ;
            //metroComboBox2.Icon.Clear();
            metroTextBox3.Clear(); ;
            metroTextBox2.Clear(); ;
            //metroDateTime1.Clear();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Reservation form = new Reservation();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }
    }
}
