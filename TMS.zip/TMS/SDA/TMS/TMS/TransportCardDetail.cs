﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMS
{
    public partial class TransportCardDetail : MetroFramework.Forms.MetroForm
    {

        public SqlDataAdapter da;
        public SqlDataReader dr;

        Connect dbconn = new Connect();
        DataTable dt = new DataTable();
        public static string customer = null, number = null, age = null, address = null, card = null;
        //Display Data in DataGridView  
        private void DisplayData()
        {
          
            DataTable dt = new DataTable();
            string query = "select CustomerID, TransportCardNo, CustomerName, ContactNumber, Age, C_Address  from [C_Transport]";
            dt = dbconn.getData(query);
        }



        public TransportCardDetail()
        {
            InitializeComponent();
        }

        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void metroGrid1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
          
        }

        private void metroTile5_Click(object sender, EventArgs e)
        {
            Transportation form = new Transportation();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }

        private void TransportCardDetail_Load(object sender, EventArgs e)
        {

        }

        private void metroTile3_Click(object sender, EventArgs e)
        {
          
            DisplayData();
       
        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
            NewTC form = new NewTC();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }
       
        private void metroTile4_Click(object sender, EventArgs e)
        {
            UpdateTC form = new UpdateTC();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
            //string customer = metroGrid1.SelectedRows[0].Cells[1].Value.ToString();
            //metroGrid1.Rows[Convert.ToInt32(e.ToString())].Cells[0].Value.ToString();
            //TMSQuerry t = new TMSQuerry();
            //t.UpdateTransportCard(customer, number, age, address, card);
        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(metroTextBox1.Text))
            {
                (metroGrid1.DataSource as DataTable).DefaultView.RowFilter = string.Empty;
            }
            else
            {
                (metroGrid1.DataSource as DataTable).DefaultView.RowFilter = string.Format("CustomerName ='{0}'", metroTextBox1.Text);
            }
        }
    }
}
