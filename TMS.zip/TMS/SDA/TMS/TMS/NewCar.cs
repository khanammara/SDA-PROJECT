﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TMS
{
    public partial class NewCar : MetroFramework.Forms.MetroForm
    {
        public static string cartype = null, rate = null, carid = null, categ = null;
        public NewCar()
        {
            InitializeComponent();
        }

        private void metroTextBox6_Click(object sender, EventArgs e)
        {

        }

        private void NewCar_Load(object sender, EventArgs e)
        {

        }

        private void metroTile2_Click(object sender, EventArgs e)
        {

            cartype = metroTextBox7.Text;
            categ = metroTextBox2.Text;
            rate = metroTextBox6.Text;
            carid = metroTextBox8.Text;


            TMSQuerry qp = new TMSQuerry();

            qp.AddCar(cartype, rate, carid, categ);

            ClearData();
        }
        private void ClearData()
        {
            metroTextBox7.Clear();
            metroTextBox2.Clear();
            metroTextBox6.Clear();
            metroTextBox8.Clear();
        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            //DistributerRecord form = new DistributerRecord();
            //this.Hide();
            //form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            //form.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            CarRecord form = new CarRecord();
            this.Hide();
            form.FormClosed += new FormClosedEventHandler(delegate { Close(); });
            form.Show();
        }
    }
}
